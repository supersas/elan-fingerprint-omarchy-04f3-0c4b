Title: ELAN 04f3:0c4b working on ThinkBook 15 G2 ITL / Omarchy — setup notes

I got enrollment and verification working for an ELAN `04f3:0c4b` reader on
a Lenovo ThinkBook 15 G2 ITL running Omarchy 4.0.4-1.

The original libfprint-git driver reported a swipe sensor and failed enrollment
with a protocol error. The existing libfprint-tod-git + libfprint-2-tod1-elan
packages selected the ELAN press driver instead. The vendor binary also needs
OpenSSL 1.1's libcrypto; its AUR build can take time.

One setup trap: the installed Omarchy fingerprint setup explicitly requested
libfprint-git, so repeating setup could undo the TOD replacement.

I prepared a short guide and a portable, opt-in helper that checks the reader,
preserves the selected packages, and backs up authentication files. It builds
on existing Omarchy and driver work; it is not a new driver. The portable
helper has 16 mocked tests and a real check-only pass, while the original
personal repair completed the actual hardware enrollment/verification.

The guide includes exact versions, sources and limitations. It does not ship
driver binaries, private logs or fingerprint data. The notes/code were prepared
with AI assistance and user-performed enrollment.

Attach/link the repository or release ZIP when posting this text.
Existing related work:
https://github.com/jcperdomoybarra/thinkpad-elan-04f3-0c4b-fingerprint-fix
