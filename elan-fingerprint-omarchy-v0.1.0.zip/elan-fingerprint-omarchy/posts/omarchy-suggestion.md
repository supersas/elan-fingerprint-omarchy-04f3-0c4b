Title: Preserve a working TOD fingerprint provider during setup (ELAN 04f3:0c4b)

I have a working ELAN `04f3:0c4b` setup on a ThinkBook 15 G2 ITL with Omarchy
4.0.4-1. The original libfprint-git path detected the reader as a swipe sensor
but enrollment failed with a device protocol error. Existing TOD/vendor
packages changed the selected device to `ELAN Fingerprint Sensor (press)`;
enrollment and verification then succeeded.

Working package combination observed on 14 October 2026:

- libfprint-tod-git 1.95.1+tod1-1
- libfprint-2-tod1-elan 0.0.1-2
- openssl-1.1 1.1.1.w-13
- fprintd 1.94.5-2

The setup script in the installed version checks for the package name
`libfprint-git`, then explicitly installs it if missing. With TOD selected,
that name is absent even though a libfprint-compatible provider is installed.
Repeating setup can therefore replace the working TOD provider. The upstream
source inspected while preparing this suggestion still explicitly names
libfprint-git, although its lock/polkit integration has evolved.

Suggested improvement: recognise an installed compatible fingerprint provider,
and separate enrollment/PAM setup from replacing that provider. For a known
problematic reader, show actionable guidance if enrollment fails, while
preserving the user's selected provider.

This is not a request to bundle an unreviewed proprietary binary. The vendor
driver and its dependencies already have separate packaging. The suggestion
is to preserve working setups rather than silently selecting a conflicting
library during re-enrollment.

I prepared a small helper and a tested-case guide with a narrow support scope,
backups and 16 mocked tests. The original repair worked on the machine; the
new portable helper's privileged setup path has not been rerun live. These
notes and code were prepared with AI assistance, with user-performed hardware
enrollment. I would welcome maintainer guidance on the appropriate upstream
implementation and provider-detection policy.

Related existing guide:
https://github.com/jcperdomoybarra/thinkpad-elan-04f3-0c4b-fingerprint-fix

Source discussed:
https://github.com/omacom/omarchy/blob/master/bin/omarchy-setup-security-fingerprint
