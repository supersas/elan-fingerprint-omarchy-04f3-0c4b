# Where to post

The project is prepared locally. Nothing has been published or sent.

## 1. Put the source on GitHub

Create a public repository at https://github.com/new named
`elan-fingerprint-omarchy`. Upload the contents of this folder to its root.
If starting from the ZIP, extract it first; uploading only the ZIP would hide
the readable README and source behind an attachment.

The folder contains the README, Bash helper, tests, licence/attribution, and
ready-to-paste drafts. It deliberately excludes the personal 52-page study
book, account paths, logs and vendor binaries.

Suggested repository description:

> Tested ELAN 04f3:0c4b / ThinkBook setup notes and an Omarchy enrollment helper
> that preserves existing TOD packages. Uses existing vendor drivers.

## 2. Share the upstream suggestion

Open Omarchy's **Suggestions** category:

https://github.com/omacom/omarchy/discussions/categories/suggestions

Paste the title and body from `posts/omarchy-suggestion.md`, then append your
new repository URL. This is a proposal with a tested case, so the Suggestions
discussion is the starting point. It is not an already-tested upstream PR or
a request for the maintainers to trust an unverified binary package.

Omarchy's older `basecamp/omarchy` links currently redirect to `omacom/omarchy`.
If maintainers request an issue or PR, follow their current contribution
instructions and test suite in a separate working clone.

## 3. Optional community write-up

Use `posts/community-post.md` in the Omarchy Discord community:

https://omarchy.org/discord

Append the repository link or attach the release ZIP. Check the community's
current channel rules before posting. A short post with the model, USB ID,
working package versions and link is enough.

## Before clicking Publish

Read the README and the validation limits. This release is a tested-case guide
and a locally tested helper, not a universally validated installer. Keep the
MIT copyright/permission notice and project credits. No private diagnostics or
biometric files are required for the post.
