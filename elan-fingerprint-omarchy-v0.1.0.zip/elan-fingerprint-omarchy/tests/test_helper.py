#!/usr/bin/env python3
"""Standard-library tests. No real sudo, biometric scans or PAM writes."""
from pathlib import Path
import os
import subprocess
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'elan-fingerprint-setup'
BASE = '#%PAM-1.0\nauth include system-auth\naccount include system-auth\n'

class HelperTests(unittest.TestCase):
    def run_bash(self, body, *args, env=None):
        return subprocess.run(['bash', '-c', 'source "$1"; shift; '+body,
                               'test', str(SCRIPT), *map(str, args)],
                              text=True, capture_output=True, env=env)

    def render(self, text):
        with tempfile.TemporaryDirectory(prefix='elan-render-test-') as temp:
            path=Path(temp)/'pam'; path.write_text(text)
            return self.run_bash('render_auth "$1"', path)

    def test_help_does_not_run_preflight(self):
        r=self.run_bash('preflight() { echo UNEXPECTED >&2; return 99; }; main --help')
        self.assertEqual(r.returncode,0); self.assertNotIn('UNEXPECTED',r.stderr)

    def test_unknown_argument_fails(self):
        self.assertNotEqual(self.run_bash('main --unknown').returncode,0)

    def test_invalid_finger_fails_before_preflight(self):
        r=self.run_bash('preflight() { echo UNEXPECTED >&2; }; main --setup --finger invalid')
        self.assertNotEqual(r.returncode,0); self.assertNotIn('UNEXPECTED',r.stderr)

    def test_check_does_not_call_setup(self):
        r=self.run_bash('preflight() { :; }; setup() { echo UNEXPECTED >&2; }; main --check')
        self.assertEqual(r.returncode,0); self.assertNotIn('UNEXPECTED',r.stderr)

    def test_password_rules_preserved(self):
        r=self.render(BASE)
        self.assertEqual(r.returncode,0)
        self.assertIn('auth include system-auth\n',r.stdout)
        self.assertIn('account include system-auth\n',r.stdout)
        self.assertLess(r.stdout.index('omarchy-hw-laptop-closed'),r.stdout.index('pam_fprintd.so'))

    def test_comment_does_not_count_as_active_rule(self):
        r=self.render('# previously tried pam_fprintd.so\n'+BASE)
        self.assertEqual(r.returncode,0)
        self.assertEqual(sum(x.startswith('auth sufficient pam_fprintd.so') for x in r.stdout.splitlines()),1)

    def test_render_is_idempotent(self):
        first=self.render(BASE); second=self.render(first.stdout)
        self.assertEqual(second.returncode,0); self.assertEqual(first.stdout,second.stdout)

    def test_existing_omarchy_spacing_is_accepted(self):
        text='auth      [success=1 default=ignore] pam_exec.so quiet /usr/bin/omarchy-hw-laptop-closed\nauth sufficient pam_fprintd.so\n'+BASE
        r=self.render(text)
        self.assertEqual(r.returncode,0); self.assertEqual(r.stdout.count('pam_fprintd.so'),1)

    def test_custom_fingerprint_options_are_rejected(self):
        r=self.render('auth required pam_fprintd.so timeout=5\n'+BASE)
        self.assertNotEqual(r.returncode,0); self.assertEqual(r.stdout,'')

    def test_duplicate_fingerprint_rules_are_rejected(self):
        r=self.render('auth sufficient pam_fprintd.so\n'*2+BASE)
        self.assertNotEqual(r.returncode,0); self.assertEqual(r.stdout,'')

    def test_custom_auth_stack_is_rejected(self):
        r=self.render('auth required pam_example.so\n'+BASE)
        self.assertNotEqual(r.returncode,0); self.assertEqual(r.stdout,'')

    def test_no_password_fallback_is_rejected(self):
        self.assertNotEqual(self.render('# no active auth lines\n').returncode,0)

    def test_legacy_polkit_password_fallback_is_preserved(self):
        r=self.render('auth required pam_unix.so\naccount required pam_unix.so\n')
        self.assertEqual(r.returncode,0); self.assertIn('auth required pam_unix.so',r.stdout)

    def test_failed_verification_prevents_pam_apply(self):
        r=self.run_bash('''
require_terminal() { :; }
prepare_pam() { :; }
sudo() { :; }
enroll_and_verify() { return 23; }
apply_pam() { echo UNEXPECTED_PAM_WRITE; }
setup student right-index-finger
''')
        self.assertEqual(r.returncode,23); self.assertNotIn('UNEXPECTED',r.stdout)

    def test_successful_verification_reaches_pam_apply(self):
        r=self.run_bash('''
require_terminal() { :; }
prepare_pam() { :; }
sudo() { :; }
enroll_and_verify() { :; }
apply_pam() { echo MOCK_APPLY; }
setup student right-index-finger
''')
        self.assertEqual(r.returncode,0); self.assertIn('MOCK_APPLY',r.stdout)

    def test_apply_failure_attempts_restore(self):
        with tempfile.TemporaryDirectory(prefix='elan-apply-test-') as temp:
            temp=Path(temp)
            for name in ('sudo','polkit-1','omarchy-lock-fingerprint'):
                (temp/name).write_text('fixture, never installed\n')
            env=dict(os.environ,TRACE=str(temp/'trace'),FAKE_BACKUP=str(temp/'backup'))
            r=self.run_bash('''
sudo() {
  printf '%s\\n' "$*" >> "$TRACE"
  case "$1" in
    mktemp) printf '%s\\n' "$FAKE_BACKUP" ;;
    test) return 1 ;;
    install) return 17 ;;
    *) return 0 ;;
  esac
}
apply_pam "$1"
''',temp,env=env)
            self.assertNotEqual(r.returncode,0)
            self.assertIn('attempting to restore',r.stderr)
            trace=(temp/'trace').read_text()
            self.assertIn('/etc/pam.d/sudo',trace)
            self.assertIn('cp -a -- '+str(temp/'backup/sudo'),trace)

if __name__=='__main__': unittest.main(verbosity=2)
