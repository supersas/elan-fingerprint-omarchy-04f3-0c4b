# Validation record

Prepared 14 October 2026. Distinguish three things:

1. **Original machine repair:** the previous personal helper enrolled and
   verified a finger on the reported ThinkBook. Driver selection changed from
   `swipe` to `press`; the final PAM files and package inventory were inspected.
2. **Portable release helper:** syntax and 16 automated local tests passed.
   The check-only path was run against the reported reader. The new `--setup`
   path was not run on live PAM files, to avoid changing an already working
   authentication setup just to test a publication artifact.
3. **Other machines / future versions:** not tested.

The Python tests use the standard library. They source Bash functions in
subprocesses, render fixture files, and mock privileged operations. They never
invoke the real sudo command, enroll a real finger, or write live PAM files.
The mocked write-failure test may compare a fixture against a live PAM path
read-only; all install/restore operations are intercepted by the mock.

Run from the repository root:

```bash
bash -n elan-fingerprint-setup
python3 tests/test_helper.py
bash elan-fingerprint-setup --check
```

The last command needs this project's actual supported hardware, packages and
desktop/system-bus access. It is separate from the platform-independent tests.
ShellCheck was not installed, so no ShellCheck pass is claimed.

## Observed limitations

- No new hardware matrix, repeated authentication benchmark or suspend test.
- The helper recognises only a narrow set of PAM auth lines and rejects others.
- Existing `system-auth` internals and existing lock fingerprint policies are
  not fully parsed or validated.
- Configuration writes are a sequence, not a multi-file atomic transaction.
- On a failed write, restoration is attempted; a failed restoration still
  requires administrator recovery. Enrollment is not undone.
- Do not run concurrently with other authentication-configuration tools.
- The helper does not verify the installed vendor binary's origin for you.

## Provenance comparison from the original repair

The vendor source binary was compared against the binary extracted from
Lenovo's original ZIP. Both source copies had SHA-256:

```text
34087826dee386a2919e8b0cd2663d1c249be1f8f1a3951bc1f2c88038d30605
```

This was a comparison before package stripping. It is not an assertion that
every future package build has these exact bytes, nor a full security audit.
No vendor binaries or biometric data are distributed in this repository.
