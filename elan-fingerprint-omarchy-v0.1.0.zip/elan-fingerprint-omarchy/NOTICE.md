# Attribution and scope

The enrollment/PAM approach is adapted from Omarchy's
`bin/omarchy-setup-security-fingerprint`, originally copyright
David Heinemeier Hansson and developed by Omarchy contributors under MIT.
The original copyright and permission notice are retained in LICENSE.

- Upstream: https://github.com/omacom/omarchy
- Source: https://github.com/omacom/omarchy/blob/master/bin/omarchy-setup-security-fingerprint
- Local baseline inspected: Omarchy package 4.0.4-1.

This release adds explicit modes, hardware/driver checks, portable account
handling, staging, root-owned backups, conservative rule handling and local
tests. It was prepared with AI assistance and human hardware enrollment.

Existing libfprint, TOD, OpenSSL and vendor-driver projects retain their own
authors and licences. This is not a newly authored fingerprint driver.
No vendor binaries, fingerprint templates, personal logs or private study-book
files are included. The MIT notice here does not relicense those other projects.
