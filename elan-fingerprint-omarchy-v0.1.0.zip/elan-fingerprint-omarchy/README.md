# ELAN 04f3:0c4b on Omarchy: tested setup notes

A tested case study and a small Bash setup helper for the ELAN `04f3:0c4b`
fingerprint reader. Uses existing TOD and vendor-driver packages. **This is
not a new fingerprint driver or an official Omarchy package.**

The original repair completed enrollment and verification on a Lenovo ThinkBook
15 G2 ITL. The portable helper in this repository is a later adaptation: its
local tests use mocks, and its check-only mode was run against that reader.
Its privileged setup path has not been rerun against the live authentication
files. See [TESTING.md](TESTING.md) for the precise validation boundary.

## The symptom and result

Before:

```text
USB ID: 04f3:0c4b
Device: ElanTech Fingerprint Sensor
scan-type: swipe
Enrollment: device protocol error
Account: no enrolled fingerprints
```

After installing the existing TOD library and ELAN plug-in:

```text
Device: ELAN Fingerprint Sensor
scan-type: press
Right index finger enrolled; verification succeeded
Fingerprint PAM rules configured for sudo, polkit and the Omarchy lock screen
```

This establishes success for this machine and session, not reliability on every
device with the same ID or across suspend/resume and future updates.

## Observed working versions

| Component | Version |
|---|---|
| Laptop | Lenovo ThinkBook 15 G2 ITL |
| Omarchy | 4.0.4-1 |
| Kernel | 7.2.5-3-omarchy |
| Reader | USB 04f3:0c4b |
| libfprint-tod-git | 1.95.1+tod1-1 |
| libfprint-2-tod1-elan | 0.0.1-2 |
| openssl-1.1 | 1.1.1.w-13 |
| fprintd | 1.94.5-2 |

The removed package was `libfprint-git 1:1.94.100.r10.g6f9479c-1`.
These are observations from 14 October 2026, not instructions to downgrade to
these versions. Review current compatibility and package recipes.

## Why these components are needed

```mermaid
flowchart TD
  A[sudo or lock screen] --> B[PAM and fprintd]
  B --> C[libfprint with TOD support]
  C --> D[ELAN vendor plug-in]
  D --> E[USB reader 04f3:0c4b]
  D --> F[OpenSSL 1.1 libcrypto]
```

- `libfprint-tod-git` provides the library interface that loads vendor plug-ins.
- `libfprint-2-tod1-elan` packages an existing ELAN binary distributed by Lenovo.
- The vendor binary requests `libcrypto.so.1.1`; OpenSSL 3's `libcrypto.so.3`
  does not satisfy that ABI. The compatibility library is installed alongside
  the newer OpenSSL, not used to downgrade the system OpenSSL.
- `fprintd` provides the fingerprint service and enrollment/verification tools.

The imported symbols include AES cipher operations and SHA-256/key-derivation
functions. This confirms cryptographic dependencies, but does not establish
every detail of the closed-source driver's internal storage or matching.

## 1. Identify your reader

```bash
lsusb -d 04f3:0c4b
```

This helper deliberately supports only that ID, exactly one fingerprint reader,
and the ELAN vendor driver reporting `press`. It requires Omarchy's
`/usr/bin/omarchy-hw-laptop-closed` and the expected base PAM files.

## 2. Install the existing packages

Review the AUR recipes and their source URLs before accepting installation.
Run each command separately in your own terminal:

```bash
MAKEFLAGS=-j4 yay -S openssl-1.1
yay -S libfprint-tod-git
yay -S libfprint-2-tod1-elan
```

The TOD library replaces the incompatible `libfprint` / `libfprint-git`
alternative; review and accept that specific replacement when prompted.
Installing OpenSSL first avoids the `libcrypto.so=1.1` dependency-resolution
problem encountered in the original combined installation request.

Build settings may be affected by local makepkg configuration. OpenSSL's
selected recipe compiled source, applied existing maintainer patches and ran
its selected tests. It can take considerable time. This helper does not build
drivers, install packages, freeze updates or edit package-manager settings.

Existing sources:

- [TOD AUR recipe](https://aur.archlinux.org/packages/libfprint-tod-git)
- [ELAN AUR recipe](https://aur.archlinux.org/packages/libfprint-2-tod1-elan)
- [OpenSSL 1.1 AUR recipe](https://aur.archlinux.org/packages/openssl-1.1)
- [ELAN packaging repository](https://github.com/TonyHoyle/libfprint-2-tod1-elan)
- [Lenovo's vendor download](https://download.lenovo.com/pccbbs/mobiles/r1sle01w.zip)

## 3. Restart and check

```bash
sudo systemctl restart fprintd
bash elan-fingerprint-setup --check
```

The check verifies packages, hardware ID and service properties. It does not
enroll a finger, edit PAM or request sudo. It may activate the on-demand
fingerprint service. Run it from your normal desktop account.

## 4. Enroll and configure

Read the helper first. **`--setup` changes system authentication files.** Run
it as your normal user in an interactive terminal, not with `sudo bash`:

```bash
bash elan-fingerprint-setup --setup
# Optional alternative finger:
# bash elan-fingerprint-setup --setup --finger left-index-finger
```

It stages proposed configuration first, requests sudo, enrolls and verifies the
selected finger, backs up existing PAM files, then applies the staged changes.
Default finger: right index. Re-enrollment may replace that finger's existing
template; use `--check` to inspect prerequisites without enrollment.

Changed files are limited to:

- `/etc/pam.d/sudo`
- `/etc/pam.d/polkit-1`
- `/etc/pam.d/omarchy-lock-fingerprint`

The helper preserves supported password fallbacks and Omarchy's lid gate.
For a new polkit file it includes `system-auth`; an existing supported file is
preserved apart from the fingerprint/lid prefix. Existing lock fingerprint
files containing an active fingerprint module are preserved, not overwritten.
Custom/duplicate fingerprint rules, unfamiliar direct auth modules and PAM
symlinks are refused. Complex authentication policies require manual review;
this is not a general-purpose PAM editor or an MFA policy validator.

## Backups and recovery

Backups are root-owned directories printed at setup time:

```text
/var/tmp/elan-fingerprint-pam.<random-suffix>/
```

Each original file is saved under its service name. A `<name>.absent` marker
means the file did not exist before setup. If an installation write fails, the
helper attempts to restore all three original file states automatically.
Enrollment itself is not rolled back; a newly saved fingerprint may remain.

If manual recovery is needed, keep an administrator terminal open. Inspect
the printed backup with `sudo ls -la <actual-backup-directory>`. Restore saved
files using `sudo cp -a` to the matching `/etc/pam.d/` paths. Remove a newly
created PAM file only when its corresponding `.absent` marker confirms that it
was absent before setup. Do not remove files that originally existed.

`/var/tmp` may be cleaned by system policy. Copy the backup to a trusted
root-owned location if it must be retained long term. Package/library rollback
is a separate operation: use package-manager records and matching archived
packages; do not replace `.so` files with ad-hoc symlinks.

## The Omarchy setup conflict

The installed 4.0.4 setup script explicitly requested `libfprint-git` whenever
its named packages were missing. After switching to TOD, repeating that setup
could reinstall `libfprint-git` and undo the working driver choice. The upstream
script inspected while preparing this release still named `libfprint-git`,
though its lock/polkit integration had changed.

The portable helper does not invoke that package-installation step. The
[upstream suggestion draft](posts/omarchy-suggestion.md) proposes preserving an
existing compatible provider and keeping enrollment separate from replacement.

## Validation, maintenance and credit

```bash
bash -n elan-fingerprint-setup
python3 tests/test_helper.py
```

Sixteen local tests cover rendering, supported password fallback preservation,
repeatability, commented mentions, refusal paths, verification gating and a
mocked configuration-write failure/restore attempt. They do not prove real
sudo, polkit, lock-screen or biometric behaviour on another machine.

The older compatibility library and proprietary driver require continuing
maintenance. Recheck after relevant updates. We have not configured package
holds or promised that arbitrary future combinations work.

Credit Omarchy, libfprint/TOD, the ELAN/Lenovo driver authors and the AUR
maintainers. Related prior work:
[existing same-reader guide](https://github.com/jcperdomoybarra/thinkpad-elan-04f3-0c4b-fingerprint-fix).
See [NOTICE.md](NOTICE.md), [LICENSE](LICENSE), and [TESTING.md](TESTING.md).
